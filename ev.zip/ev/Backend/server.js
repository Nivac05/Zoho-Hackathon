const express = require("express");
const fs = require("fs");
const jwt = require("jsonwebtoken");
const bodyParser = require("body-parser");
const cors = require("cors");
require("dotenv").config();

const app = express();
const PORT = 5000;
const SECRET_KEY = "your_secret_key";

app.use(cors());
app.use(bodyParser.json());

const users = require("./data/users.json");
const bookings = require("./data/bookings.json");

const saveData = (file, data) => {
  fs.writeFileSync(`./data/${file}.json`, JSON.stringify(data, null, 2));
};

app.post("/login", (req, res) => {
  const { email, password } = req.body;
  const user = users.find((u) => u.email === email && u.password === password);
  if (!user) return res.status(401).json({ message: "Invalid credentials" });

  const token = jwt.sign({ email: user.email, role: user.role }, SECRET_KEY, { expiresIn: "1h" });
  res.json({ token });
});

const stations = [
  { id: 1, name: "Anna Nagar 3rd cross street ", location: "Anna Nagar, Chennai", available_slots: 6,  contact: 985548736, lat: 13.0827, lng: 80.2171 },
  { id: 2, name: "No:8, Maharaj Residence T Nagar ", location: "T Nagar, Chennai", available_slots: 3,  lat: 13.0418, contact: 985548736, lng: 80.2333 },
  { id: 3, name: "block A, India Bulls Apartments", location: "Velachery, Chennai", available_slots: 4, contact: 985548736, lat: 12.9766, lng: 80.2209 },
  { id: 5, name: "Adair high rise Solar Charge", location: "Adyar, Chennai", available_slots: 6,  lat: 13.0067,contact: 985548736, lng: 80.2560 },
  { id: 6, name: "Racecourse towers Plaza", location: "Guindy, Chennai", available_slots: 2,  lat: 13.0072,contact: 985548736, lng: 80.2206 },
  { id: 7, name: "Perungudi Tech towers", location: "Perungudi, Chennai", available_slots: 5, contact: 985548736, lat: 12.9655, lng: 80.2449 },
  { id: 8, name: "Casagrand Avenis Villas", location: "Tambaram, Chennai", available_slots: 3, contact: 985548736, lat: 12.9249, lng: 80.1212 },
  { id: 9, name: "Narayana's Residence, North Street", location: "Mylapore, Chennai", available_slots: 4, contact: 985548736, lat: 13.0331, lng: 80.2689 },
  { id: 10, name: "Metrozone Towers, F Block", location: "Porur, Chennai", available_slots: 6, contact: 985548736, lat: 13.0358, lng: 80.1619 }
];

app.get("/stations", (req, res) => {
  res.json(stations);
});

app.post("/book", (req, res) => {
  const { email, stationId, timeSlot } = req.body;
  const booking = { id: Date.now(), email, stationId, timeSlot };
  bookings.push(booking);
  saveData("bookings", bookings);
  res.json({ message: "Booking confirmed", booking });
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
