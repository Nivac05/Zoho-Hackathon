import React, { useEffect, useState } from "react";

const BookingConfirmation = () => {
  const [bookingDetails, setBookingDetails] = useState(null);

  useEffect(() => {
    const details = JSON.parse(localStorage.getItem("bookingDetails"));
    if (details) setBookingDetails(details);
  }, []);

  if (!bookingDetails) {
    return <h2>No Booking Found</h2>;
  }

  return (
    <div className="p-6">
      <h2>Booking Confirmed ✅</h2>
      <p><strong>Station:</strong> {bookingDetails.stationName}</p>
      <p><strong>Location:</strong> {bookingDetails.location}</p>
      <p><strong>Time Slot:</strong> {bookingDetails.timeSlot}</p>
      <p><strong>Message:</strong> {bookingDetails.message}</p>
      <p><strong>Contact:</strong> {bookingDetails.contact}</p>
    </div>
  );
};

export default BookingConfirmation;
