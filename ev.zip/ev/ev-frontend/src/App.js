import React, { useState, useEffect } from "react";
import axios from "axios";

const App = () => {
  const [token, setToken] = useState(null);
  const [stations, setStations] = useState([]);
  const [nearestStations, setNearestStations] = useState([]);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [bookingMessage, setBookingMessage] = useState("");

  useEffect(() => {
    if (token) {
      axios
        .get("http://localhost:5000/stations", { headers: { Authorization: `Bearer ${token}` } })
        .then((res) => {
          setStations(res.data);
          getUserLocation(res.data);
        })
        .catch((err) => console.error(err));
    }
  }, [token]);

  const getUserLocation = (allStations) => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const userLat = position.coords.latitude;
          const userLng = position.coords.longitude;
          const filteredStations = filterNearbyStations(userLat, userLng, allStations);
          setNearestStations(filteredStations);
        },
        (error) => {
          console.error("Geolocation Error:", error);
          alert("Unable to fetch location. Showing all stations.");
          setNearestStations(allStations);
        }
      );
    } else {
      alert("Geolocation is not supported by your browser.");
      setNearestStations(allStations);
    }
  };

  const filterNearbyStations = (userLat, userLng, stations) => {
    return stations
      .map((station) => ({
        ...station,
        distance: getDistance(userLat, userLng, station.lat, station.lng),
      }))
      .filter((station) => station.distance <= 18) 
      .sort((a, b) => a.distance - b.distance);
  };

  const getDistance = (lat1, lon1, lat2, lon2) => {
    const toRad = (value) => (value * Math.PI) / 180;
    const R = 6371; //Radius of Earth
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c; // Distance in km
  };

  const login = async () => {
    try {
      const response = await axios.post("http://localhost:5000/login", { email, password });
      setToken(response.data.token);
    } catch (error) {
      alert("Login failed");
    }
  };

  const bookSlot = async (stationId, stationName, location) => {
    try {
      const response = await axios.post(
        "http://localhost:5000/book",
        { email, stationId, timeSlot: "10:00 AM - 11:00 AM" },
        { headers: { Authorization: `Bearer ${token}` } }
      );
  
      const bookingDetails = {
        stationName,
        location,
        timeSlot: "10:00 AM - 11:00 AM",
        message: response.data.message,
        contact: 9843298604
      };
  
      const newTab = window.open("/booking-confirmation", "_blank");
      
      localStorage.setItem("bookingDetails", JSON.stringify(bookingDetails));
  
    } catch (error) {
      alert("Booking failed");
    }
  };
  

  return (
    <div className="p-6">
      {!token ? (
        <div>
          <h2>Login</h2>
          <input type="email" placeholder="Email" onChange={(e) => setEmail(e.target.value)} />
          <input type="password" placeholder="Password" onChange={(e) => setPassword(e.target.value)} />
          <button onClick={login}>Login</button>
        </div>
      ) : (
        <div>
          <h2>Nearest EV Charging Stations (Within 18 km)</h2>
          {nearestStations.length > 0 ? (
            nearestStations.map((station) => (
              <div key={station.id} className="border p-4 mb-2">
                <h3>{station.name}</h3>
                <p>{station.location}</p>
                <p>Slots Available: {station.available_slots}</p>
                <p>Price per kWh: ₹{station.price_per_kwh}</p>
                <p>Distance: {station.distance.toFixed(2)} km</p>
                <button onClick={() => bookSlot(station.id, station.name, station.location)}>Book Slot </button>

              </div>
            ))
          ) : (
            <p>No charging stations available within 18 km.</p>
          )}
          {bookingMessage && <p>{bookingMessage}</p>}
        </div>
      )}
    </div>
  );
};

export default App;
